package mainline;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

import addresses.IndiaAddress;
import addresses.ParentAddress;
import addresses.QatarBusinessAddress;
import addresses.UnitedStatesAddress;
import dictionary.DictEntry;
import dictionary.Dictionary;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;


/*******
* <p> Title: UserInterface Class. </p>
* 
* <p> Description: A JavaFX application: This controller class that provide the User Interface and 
* the business logic for the application.</p>
* 
* <p> Copyright: Lynn Robert Carter © 2018-08-28 </p>
* 
* @author Yash & Lynn Robert Carter
* 
* @version 1.00	2018-08-28 Baseline
* @version 1.10 2018-11-12 Personal Knowledge Management Tool
* 
*/
public class UserInterface {
		/**********************************************************************************************

	Class Attributes
	
	**********************************************************************************************/
	
	// Attributes used to establish the display and control panel within the window provided to us
	// This values are passed in when this class is instantiated
	private static double CONTROL_PANEL_HEIGHT;
	private static double WINDOW_HEIGHT;
	private static double WINDOW_WIDTH;
	
	private Stage primaryStage;
	
	private static double MARGIN_WIDTH = 5;
	
	
	// These attributes put a graphical frame around the portion of the window that receives the
	// text for the various tabs
	private Rectangle rect_outer;
	private Rectangle rect_middle;
	private Rectangle rect_inner;
	
	// This is the root of the user interface
	private Group theRoot = null;
	
	//-------------------------------------------------------------------------
	private Tab contactsTab = new Tab("Contacts     ");
    private Group contactControls = new Group();
	
	private boolean contactFileReadControlsAreSetUp = false;
	private Group contactFileReadControls = new Group();
	
	private Tab dictionaryTab = new Tab("Dictionary     ");
	private Group dictionaryControls = new Group();
	
	private boolean dictionaryFileReadControlsAreSetUp = false;
	private Group dictionaryFileReadControls = new Group();
	
	private boolean dictionaryFindControlsAreSetUp = false;
	private Group dictionaryFindControls = new Group();
	
	private Tab spareTab = new Tab("Notes & ToDo List    ");

	
	//------------------------------------
	// Class attributes for Dictionary Tab
	
	// This is the attribute that holds the reference to the baseline dictionary
	private Dictionary theDictionary = null;

	
	// The User Interface widgets used to control the Dictionary functions
	private Label lbl_FileName = new Label("Enter the dictionary's file name here:");
	private TextField fld_DictionaryFileName = new TextField();
	private String str_DictionaryFileName;
	private Label lbl_FileFound = new Label("");
	private Label lbl_FileNotFound = new Label("");
	private Label lbl_ErrorDetails = new Label("");
	private Scanner scnr_Input;
	private String str_FileContentsError = "";
	private int numberOfLinesInTheInputFile = 0;
	private Button btn_Dictionary_Load = new Button("Load the dictionary");
	private Label lbl_NumberOfDefinitions = new Label("");
	private Label lbl_EnterSearchText = new Label("Enter search text:");
	private TextField fld_SearchText = new TextField();
	private Button btn_Search = new Button("Search");
	private Label lbl_NumberOfSearchItemsFound = new Label("");
	private int numberOfSearchItemsFound = -1;
	private TabPane tabPane;
	
	final Stage addDialog1 = new Stage();
	final Stage editDialog1 = new Stage();
	private Label lbl_DefinitionName1 = new Label("1. Contact Name");
	private Label lbl_Definition1 = new Label("2. Contact");
	private Label lbl_Definition2 = new Label("1. Edit a Contact");
	private TextField fld_DefinitionName1 = new TextField();
	private TextArea txt_Definition1 = new TextArea();
	private TextArea txt_Definition2 = new TextArea();
	private Label lbl_Saveadded1 = new Label("3. Save the updated Contacts");
	private Button btn_Saveadded1 = new Button("Save");
	private Label lbl_Saveadded2 = new Label("2. Save the updated Contacts");
	private Button btn_Saveadded2 = new Button("Save");
	private TextArea contacts = new TextArea();
	private Button btn_LoadContacts = new Button("Load Contacts");
	private Label lbl_update = new Label("");
	private Button btn_addPopup1 = new Button("Add");
	private Button btn_editPopup1 = new Button("Edit");
	
	// GUI element for the Edit Pop-up
    final Stage editDialog = new Stage();
	private Button btn_EditPopup = new Button("Edit");
	private boolean editDeletePopupDisplayed = false;
	private Label lbl_1SelectDefinition = new Label("1. Select a definition");
	private List <DictEntry> editDefinitionList = new Vector <DictEntry>();
	private ComboBox <String> editComboBox = new ComboBox <String>();
	private Label lbl_2EditDefinition = new Label("2. Edit a definition");
	private Label lbl_2aWord = new Label("The word or phrase to be defined");
	private TextField fld_2aWord = new TextField();
	private Label lbl_2bDefinition = new Label("The definition of the word or phrase");
	private TextArea txt_2bDefinition = new TextArea();
	private Label lbl_3saveNotesDefinition = new Label("3. Save a definition");
	private int ndxsaveNotesEdit;
	private Button btn_saveNotesEditChanges = new Button("Save");
	private Group spare= new Group();
	// GUI elements for the Delete Pop-up
	private Button btn_DeletePopup = new Button("Delete");
	private TextField Spare= new TextField("Enter Task here");
	private TextArea NotesContent = new TextArea("To do list: Click on add to add new items");
	private TextArea ToDoContent = new TextArea("To do list: Click on add to add new items");
	private TextArea contactsContent = new TextArea();
	private TextArea contentDict = new TextArea();

	/**********
	 * This constructor establishes the user interface with the needed tabs and widgets
	 * 
	 * @param r		The root of the widgets
	 * @param t		The TabPane we are to use
	 * @param h		The height we should use for the application window
	 * @param w		The width of the application window
	 * @param cph	The location of the controls widgets
	 */
	public UserInterface(Stage ps, Group r, TabPane t, double h, double w, double cph) {
		
		/**********************************************************************************************

		Class Attributes
		
		**********************************************************************************************/
		
		primaryStage = ps;

		// Set the Stage boundaries to the visual bounds so the window does not totally fill the screen 
		WINDOW_WIDTH = w;
		WINDOW_HEIGHT = h;
		CONTROL_PANEL_HEIGHT = cph;
		
		tabPane = t;
		theRoot = r;
		
	    editDialog.initModality(Modality.APPLICATION_MODAL);
        editDialog.initOwner(primaryStage);
		
		// These attributes put a graphical frame around the portion of the window that holds the
		// information this knowledge management tool hold, displays, and manipulates.  These
		// graphical elements give a three-dimensional look to the user interface.
		rect_outer =  new Rectangle(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
		rect_middle = new Rectangle(5, 5, WINDOW_WIDTH-10, CONTROL_PANEL_HEIGHT-15);
		rect_inner =  new Rectangle(6, 6, WINDOW_WIDTH-12, CONTROL_PANEL_HEIGHT-17);
		
		// Set the fill colors for the border frame to give that three-dimensional look
		rect_outer.setFill(Color.LIGHTGRAY);
		rect_middle.setFill(Color.BLACK);
		rect_inner.setFill(Color.WHITE);
        
		// Use a BorderPane to hold the various tabs
        BorderPane borderPane = new BorderPane();
        borderPane.setLayoutX(9);							// The left edge
        borderPane.setLayoutY(9);							// The upper edge
        borderPane.setPrefWidth(WINDOW_WIDTH-18);			// The right edge
        borderPane.setPrefHeight(CONTROL_PANEL_HEIGHT-24);	// The lower edge
        
        // Sets up the basic elements for the contacts tab (which are not yet implemented)
        borderPane.setCenter(tabPane);
        contactsTab.setOnSelectionChanged((event) -> { contactsChanged(); });
        TextArea contactsContent = new TextArea("This is the text for contacts.");
        contactsContent.setEditable(true);
        contactsTab.setContent(contactsContent);
        tabPane.getTabs().add(contactsTab);

        // Sets up the basic elements for the dictionary tab (which has some functions implemented)
        dictionaryTab.setOnSelectionChanged((event) -> {  dictionaryChanged(); });
        contentDict = new TextArea("This is the text for dictionary definitions.");
	    contentDict.setEditable(false);
        dictionaryTab.setContent(contentDict);
        tabPane.getTabs().add(dictionaryTab);

        // Sets up the basic elements for the contacts tab (this is for future functions)
        spareTab.setOnSelectionChanged((event) -> {  spareChanged(); });
        
        
        NotesContent.setEditable(false);
        spareTab.setContent(NotesContent);
        ToDoContent.setEditable(false);
        tabPane.getTabs().add(spareTab);
        
		// Place all of the just-initialized GUI elements into the pane with the exception of the
		// Stop button.  That widget will replace the Start button, once the Start has been pressed
        
        Button saveNotes= new Button("save Notes");
        Button saveToDoList= new Button("save List");
        Button Delete= new Button("Delete");
        Button Add= new Button("Add");
        Button Show= new Button("Show File");
        Button Showfile= new Button("Show File");
                
        setupTextUI(Spare, "Arial", 14, WINDOW_WIDTH / 1.6, Pos.BASELINE_LEFT,          
				50, CONTROL_PANEL_HEIGHT -65, true);
        
        Spare.setVisible(true);
       
         
        setupButtonUI(Delete, "Arial", 14, 100, Pos.CENTER, WINDOW_WIDTH - 300,  
				CONTROL_PANEL_HEIGHT +75);
        setupButtonUI(saveNotes, "Arial", 14, 100, Pos.CENTER, 325,  
				CONTROL_PANEL_HEIGHT +75);
        setupButtonUI(saveToDoList, "Arial", 14, 100, Pos.CENTER, 425,  
				CONTROL_PANEL_HEIGHT +75);
        setupButtonUI(Show, "Arial", 14, 100, Pos.BASELINE_LEFT, 50,  
				CONTROL_PANEL_HEIGHT +75);
        setupButtonUI(Add, "Arial", 14, 80, Pos.BASELINE_LEFT, 200,  
				CONTROL_PANEL_HEIGHT +75);
        setupButtonUI(Showfile, "Arial", 14, 100, Pos.BASELINE_LEFT, 50,  
				CONTROL_PANEL_HEIGHT +75);
        
       saveToDoList.setOnAction((event)->{
       	try {
				saveNotesTheList();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	});
        
        saveNotes.setOnAction((event)->{
        	try {
				saveNotesTheNotes();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	});
        
        Delete.setOnAction((event) -> {
    	
    		ToDoContent.setText(" ");
    });
        Add.setOnAction((event) -> {
        	
    		ToDoContent.setText(Spare.getText());
    });
    
        Show.setOnAction((event) -> {
        	
    
        	String fileName = "File1.txt";
        	File file = new File(fileName);
        	FileReader fr = null;
			try {
				fr = new FileReader(file);
			} catch (FileNotFoundException e) {
			e.printStackTrace();
			}
        	BufferedReader br = new BufferedReader(fr);
        	String line;
        	try {
				while((line = br.readLine()) != null){
				   ToDoContent.setText(line.toString()+"\n" + Spare.getText());
				  
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
        	});
        
        Showfile.setOnAction((event) -> {
        	
            
        	String fileName = "File2.txt";
        	File file = new File(fileName);
        	FileReader fr = null;
			try {
				fr = new FileReader(file);
			} catch (FileNotFoundException e) {
			e.printStackTrace();
			}
        	BufferedReader br = new BufferedReader(fr);
        	String line;
        	try {
				while((line = br.readLine()) != null){
				    //process the line
				   contactsContent.setText(line.toString());
				  
				}
			} catch (IOException e) {
			e.printStackTrace();
			}
        	});
      
        final ToggleGroup group = new ToggleGroup();
        RadioButton Notes = new RadioButton("Notes");
        Notes.setToggleGroup(group);
        Notes.setSelected(false);
        RadioButton ToDoList = new RadioButton("To-Do List");
        ToDoList.setToggleGroup(group);
        ToDoList.setSelected(false);
        saveNotes.setVisible(false);
        saveToDoList.setVisible(false);
        Delete.setVisible(false);
        Show.setVisible(false);
        Add.setVisible(false);
        Spare.setVisible(false);
        setupRadioButtonUI(Notes, "Arial", 14, 100, Pos.BASELINE_LEFT, WINDOW_WIDTH - 275,  
				CONTROL_PANEL_HEIGHT + 24);
        
        setupRadioButtonUI(ToDoList, "Arial", 14, 100, Pos.BASELINE_LEFT, 200,  
				CONTROL_PANEL_HEIGHT + 24);
        ToDoList.setOnAction((event) -> { 
        	saveToDoList.setVisible(true);
            ToDoContent.setText("To do list ");
            ToDoContent.setEditable(true);
            Spare.setVisible(true);
            saveNotes.setVisible(false);
            Delete.setVisible(true);
            Show.setVisible(true);
            Add.setVisible(true);
            spareTab.setContent(ToDoContent);
            		}
        			);
        
        Notes.setOnAction((event) -> { 
        NotesContent.setText("Add your Notes Below: ");
        NotesContent.setEditable(true);
        saveNotes.setVisible(true);
        saveToDoList.setVisible(false);
        Delete.setVisible(false);
        Show.setVisible(false);
        Add.setVisible(false);
        Spare.setVisible(false);
        spareTab.setContent(NotesContent);
        		}
    			);
        
        contactControls.getChildren().addAll( btn_addPopup1, btn_editPopup1, lbl_update, btn_LoadContacts);
        
        spare.getChildren().addAll(Notes,ToDoList,saveNotes,saveToDoList,Delete,Show,Add,Spare);
	// Stop button.  That widget will replace the Start button, once the Start has been pressed
		theRoot.getChildren().addAll(rect_outer, rect_middle, rect_inner, borderPane,spare,contactControls);
    }
	

	//-------------------------------------------------------------------------------------
	//
	// The following private methods are used to simplify the code to initialize GUI widgets
	//
	//-------------------------------------------------------------------------------------

	/**********
	 * Private local method to initialize the standard fields for a label
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y){
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}
	
	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e){
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);		
		t.setEditable(e);
	}
	
	/**********
	 * Private local method to initialize the standard fields for a text area
	 */
	private void setupTextAreaUI(TextArea a, String ff, double f, double w, double h, double x, double y, boolean e){
		a.setFont(Font.font(ff, f));
		a.setMinWidth(w);
		a.setMaxWidth(w);
		a.setMinHeight(h);
		a.setMaxHeight(h);
		a.setLayoutX(x);
		a.setLayoutY(y);		
		a.setEditable(e);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);		
	}
	
	private void setupRadioButtonUI(RadioButton b, String ff, double f, double w, Pos p, double x, double y){
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);		
	}
	//---------------------------------------------------------------------------------------------
	//
	// The following private methods are used to manage the various kinds of knowledge this
	// tools supports (Contacts - Eventually; Dictionary - Basic functionality; Spare - for later
	//
	//---------------------------------------------------------------------------------------------

	/**********
	 * Whenever the user enters or leaves the Contacts Tab, this method is called
	 */

			// Demonstrate that the United States Address holds the data and prints it properly
			UnitedStatesAddress lrcarterAddress = new UnitedStatesAddress (
			"Lynn Robert Carter",
			"3857 East Equestrian Trail",
			"Phoenix",
			"Arizona",
			"85044-3008",
			"USA");
			
			// Demonstrate that the Qatar Address holds the data and prints it properly
			QatarBusinessAddress cmuQatarAddress = new QatarBusinessAddress (
			"Office of Undergraduate Admissions",
			"Carnegie Mellon University",
			"c/o Qatar Foundation",
			"P.O. Box 24866",
			"Doha",
			"Qatar");
		
			//Demonstrate that the India Address holds the data and prints it properly
			IndiaAddress MMU = new IndiaAddress(
			"Maharishi Markandeshwar (Deemed to be University)",
			"Ambala - Yamunanagar Highway",
			"Mullana - Ambala",
			" 33-207",
			"(Haryana)",
			"India"
			);
	
		// Demonstrate that the Parent address holds the data and prints it properly
		ParentAddress Home = new ParentAddress(
			"Flat No. 103",
			"Hollyhock Block",
			"Amravati Enclave - Panchkula",
			" 134107",
			"(Haryana)",
			"India"
			);
	
	private void contactsChanged() {
		
		// Determine if entering the Tab or leaving it
		if (!contactsTab.isSelected()) {
		// When the execution gets here, the user is leaving the tab
		contactControls.setVisible(false);
		return;
		}
		
		if (contactFileReadControlsAreSetUp) {
		// If the controls have already been set up, make sure they are now visible
		contactFileReadControls.setVisible(true);
		}
		else {
		// Since the controls have not yet been set up, set them up, make them visible,
		// and set the flag so we don't try to set them up twice.
		contactSetUpFindControls();
		contactFileReadControlsAreSetUp = true;
		contactFileReadControls.setVisible(true);
		}
		contactControls.setVisible(true);
		
	}
		
		/**********
		 * Display the Contact controls in the GUI
		 */
		private void contactSetUpFindControls() {
		
		// Label the updates of the modification held in the contact list
		setupLabelUI(lbl_update, "Arial", 20, WINDOW_WIDTH-20, Pos.BASELINE_LEFT, 
		150, WINDOW_WIDTH - 275);
		lbl_update.setStyle("-fx-text-fill: green; -fx-font-size: 18;");
		
		setupButtonUI(btn_LoadContacts, "Arial", 14, 50, Pos.BASELINE_CENTER, WINDOW_WIDTH - 550,  
				CONTROL_PANEL_HEIGHT);
		
		// Establish a GUI Button to open the pop-up window to add a new contact
		
		setupButtonUI(btn_addPopup1, "Arial", 14, 50, Pos.BASELINE_CENTER, WINDOW_WIDTH - 60,  
		CONTROL_PANEL_HEIGHT);
		
		// Establish a GUI Button to open the pop-up window to edit or delete the contact from the contact list
		setupButtonUI(btn_editPopup1, "Arial", 14, 50, Pos.BASELINE_CENTER, WINDOW_WIDTH - 130,  
		CONTROL_PANEL_HEIGHT);
		
		// Disable the button until the contact list has been load
		btn_addPopup1.setDisable(true); 
		btn_editPopup1.setDisable(true);
		
		lbl_update.setVisible(false);
		btn_LoadContacts.setOnAction((event) -> { searchContacts(); });
		btn_addPopup1.setOnAction((event) -> { setupContactAddPopup(); });
		btn_editPopup1.setOnAction((event) -> { setupContactEditPopup(); });
		
		}
		
		private void searchContacts() {
			

			}
		
		
		

		private void setupContactEditPopup() {
	// Set up the pop-up modal dialogue window
        editDialog1.setTitle("Edit the contacts");
        
        Group ContactsEditControls = new Group();
     
        // Set up the pop-up window
        Scene dialogScene = new Scene(ContactsEditControls, 500, 400);
        
        // Set up the fields for the edit pop-up window
        setupLabelUI(lbl_Definition2, "Arial", 14, 100, Pos.BASELINE_LEFT, 10, 20);
        setupTextAreaUI(txt_Definition2, "Arial", 14, 450, 275, 30, 50, true);
        setupLabelUI(lbl_Saveadded2, "Arial", 14, 100, Pos.BASELINE_LEFT, 10, 335);
       
     
	    	// set the text of addresses to display on the user interface.
	        txt_Definition2.setText(lrcarterAddress+ "\n"+ "************" + "\n" + cmuQatarAddress + "\n" +  "************" + "\n" + MMU + "\n" +  "************" + "\n" + Home);	
	     
	  
        // Set the screen so we can see it
        editDialog1.setScene(dialogScene);
        
        setupButtonUI(btn_Saveadded2, "Arial", 12, 50, Pos.BASELINE_LEFT, 30, 360);
        btn_Saveadded2.setOnAction((event) -> { saveTheEditedContact(); });
        
        // Populate the pop-up window with the GUI elements
        ContactsEditControls.getChildren().addAll( lbl_Definition2, lbl_Saveadded2,
        	txt_Definition2, btn_Saveadded2);

        // Show the pop-up window
        editDialog1.show();
	}

		/**********
		 * This method established the pop-up window that is used to add new contact into the contact list 
		 * and then save it
		 */
		private void setupContactAddPopup() {
		// Set up the pop-up modal dialogue window
	        addDialog1.setTitle("Add a new Contacts");
	        Group ContactsEditControls = new Group();
	     
	        // Set up the pop-up window
	        Scene dialogScene = new Scene(ContactsEditControls, 500, 400);
	        
	        // Set up the fields for the add pop-up window
	        setupLabelUI(lbl_DefinitionName1, "Arial", 14, 100, Pos.BASELINE_LEFT, 10, 10);
	        setupLabelUI(lbl_Definition1, "Arial", 14, 100, Pos.BASELINE_LEFT, 10, 100);
		setupTextUI(fld_DefinitionName1, "Arial", 14, 450, Pos.BASELINE_LEFT, 30, 50, true);
	        setupTextAreaUI(txt_Definition1, "Arial", 14, 450, 190, 30, 130, true);
	        setupLabelUI(lbl_Saveadded1, "Arial", 14, 100, Pos.BASELINE_LEFT, 10, 335);
	     
	        // Set the screen so we can see it
	        addDialog1.setScene(dialogScene);
	        
	        setupButtonUI(btn_Saveadded1, "Arial", 12, 50, Pos.BASELINE_LEFT, 30, 360);
	        btn_Saveadded1.setOnAction((event) -> { saveTheAddedContact(); });
	        
	        // Populate the pop-up window with the GUI elements
	        ContactsEditControls.getChildren().addAll(lbl_DefinitionName1, lbl_Definition1, 
	        	fld_DefinitionName1, txt_Definition1, lbl_Saveadded1, btn_Saveadded1);

	        // Show the pop-up window
	        addDialog1.show();
		
		}
		
		private void saveTheEditedContact() {
			
			// Get the updated contact list from the text area and store it into a string
		    	String saveThisEditedContact = txt_Definition2.getText();
		    	
		    	System.out.println("\nUpdated Contact List:\n" + saveThisEditedContact);

		    	contacts.setText(saveThisEditedContact);
		    	
		     	// Set the Edited contact list in the display area
		    	 contactsTab.setContent(contacts);
		    	 
		    	 // Show the message after the contact list has been edited
		    	 lbl_update.setText("Contact has been Edited");
		    	 lbl_update.setVisible(true);
		    	 
		        // Hide and close the pop-up window
		    	editDialog1.hide();
		        editDialog1.close();
			
			}

			/**********
			 * This method to used to when the user adds a new contact and save the contact into the contact list
			 */
			private void saveTheAddedContact() {
			
		    	String ContactName = fld_DefinitionName1.getText();
		    	String ContactInformation = txt_Definition1.getText();
		    	System.out.println("\nThe word of phrase for the save:\n" + ContactName);
		    	System.out.println("\nThe definition for the word or phrase for the save:\n" + ContactInformation);

		    	contacts.appendText("\n*************\n" + ContactName + ":\n" + ContactInformation);
		    	
		    	// Set the Edited contact list in the display area
		    	 contactsTab.setContent(contacts);
		    	 
		    	// Show the message after the new contact has been successfully added
		    	 lbl_update.setText("Contact has been Saved");
		    	 lbl_update.setVisible(true);
		    	 
		        // Hide and close the pop-up window
		    	addDialog1.hide();
		        addDialog1.close();
		        
			}

	//---------------------------------------------------------------------------------------------

	/**********
	 * Whenever the user enters or leaves the Dictionary Tab, this method is called
	 */
	private void dictionaryChanged() {
		if (!dictionaryTab.isSelected()) {
			
		// The application is leaving the dictionary tab, so hide any controls that might have
		// been made visible
			dictionaryControls.setVisible(false);
			return;
		}
		
		// If we get here, the dictionary tab is active, so we need to determine which of the
		// controls should be visible and then make sure they are set up and visible
		if (theDictionary == null) {
			
			// No dictionary has been been defined yet, so the only option is the controls for the
			// user to specify the file name, the label for the input field, the message field, and
			// the button to cause the application to read in the file (should the input be there
			// be of the proper syntax).
			if (dictionaryFileReadControlsAreSetUp) {
				// If the controls have already been set up, make sure they are now visible
				dictionaryFileReadControls.setVisible(true);
			}
			else {
				// Since the controls have not yet been set up, set them up, make them visible,
				// and set the flag so we don't try to set them up twice.
				dictionarySetUpFileReadControls();
				dictionaryFileReadControlsAreSetUp = true;
				dictionaryFileReadControls.setVisible(true);
			}
			
		    Platform.runLater(new Runnable() {public void run() {fld_DictionaryFileName.requestFocus();
		    	fld_DictionaryFileName.selectEnd();} });
		}
		else {
			// The dictionary has been read it, so we know we must hide the controls used to read
			// in the dictionary
			dictionaryFileReadControls.setVisible(false);
			
			// If the find a word/String has not been set up, set them up and remember that it has been done.
			if (!dictionaryFindControlsAreSetUp) {
				dictionarySetUpFindControls();
				dictionaryFindControlsAreSetUp = true;
				dictionaryFindControls.setVisible(true);
			}
			
		    Platform.runLater(new Runnable() {public void run() {fld_SearchText.requestFocus();
		    	fld_SearchText.selectEnd();} });
		}
		
		// Make the dictionary controls visible, regardless of which version is current active
		dictionaryControls.setVisible(true);
	}
	
	private void dictionarySetUpFileReadControls() {

		// Label the text field that is to receive the file name.
		setupLabelUI(lbl_FileName, "Arial", 14, WINDOW_WIDTH-20, Pos.BASELINE_LEFT, 
				MARGIN_WIDTH, CONTROL_PANEL_HEIGHT);

		// Establish the text input widget so the user can enter in the name of the file that holds
		// the data about which cells are alive at the start of the simulation
		setupTextUI(fld_DictionaryFileName, "Arial", 14, WINDOW_WIDTH / 2, Pos.BASELINE_LEFT, 
				MARGIN_WIDTH, CONTROL_PANEL_HEIGHT + 24, true);

		// Establish the link between the text input widget and a routine that checks to see if
		// if a file of that name exists and if so, whether or not the data is valid
		fld_DictionaryFileName.textProperty().addListener((observable, oldValue, newValue) -> {checkFileName(); });

		// Establish a GUI button the user presses when the file name have been entered and the
		// code has verified that the data in the file is valid (e.g. it conforms to the requirements)
		setupButtonUI(btn_Dictionary_Load, "Arial", 14, 100, Pos.BASELINE_LEFT, WINDOW_WIDTH - 275,  
				CONTROL_PANEL_HEIGHT + 24);

		// Establish the link between the button widget and a routine that loads the data into theData
		// data structure
		btn_Dictionary_Load.setOnAction((event) -> { loadTheData(); });
		btn_Dictionary_Load.setDisable(true);

		// The following set up the control panel messages for messages and information about errors
		setupLabelUI(lbl_FileFound, "Arial", 14, 150, Pos.BASELINE_LEFT, 320, CONTROL_PANEL_HEIGHT);
		lbl_FileFound.setStyle("-fx-text-fill: green; -fx-font-size: 14;");

		setupLabelUI(lbl_FileNotFound, "Arial", 14, 150, Pos.BASELINE_LEFT, 320, CONTROL_PANEL_HEIGHT);
		lbl_FileNotFound.setStyle("-fx-text-fill: red; -fx-font-size: 14;");

		setupLabelUI(lbl_ErrorDetails, "Arial", 14, WINDOW_WIDTH, Pos.BASELINE_LEFT, 20,
				CONTROL_PANEL_HEIGHT);

		lbl_ErrorDetails.setStyle("-fx-text-fill: red; -fx-font-size: 14;");

		
		dictionaryFileReadControls.getChildren().addAll(lbl_FileName, fld_DictionaryFileName, btn_Dictionary_Load,
				lbl_FileFound, lbl_FileNotFound, lbl_ErrorDetails);
		
		dictionaryControls.getChildren().add(dictionaryFileReadControls);
		
		theRoot.getChildren().add(dictionaryControls);
	}


	/**********
	 * This routine checks, after each character is typed, to see if the dictionary file is there
	 * and if so, sets up a scanner to it and enables a button to read it and verify that it is ready
	 * to be used by the application.
	 * 
	 * If a file of that name is found, it checks to see if the contents conforms to the specification.
	 * 		If it does, a button is enabled and a green message is displayed
	 * 		If it does not, a button is disabled and a red error message is displayed
	 * If a file is not found, a warning message is displayed and the button is disabled.
	 * If the input is empty, all the related messages are removed and the  button is disabled.
	 */
	private void checkFileName(){								// Whenever this text area is changed, this routine
		str_DictionaryFileName = fld_DictionaryFileName.getText();	// is called to see if it is valid.
		if (str_DictionaryFileName.length()<=0){		// If the file name is empty, there are no errors	
			lbl_FileFound.setText("");					// so the messages as set to empty
			lbl_FileNotFound.setText("");
			scnr_Input = null;							// and the input scanner is disabled
		} 
		else 	// If there is something in the file name text area this routine tries to open it
			try {										// and establish a scanner.
				scnr_Input = new Scanner(new File(str_DictionaryFileName));

				// There is a readable file there... this code checks the data to see if it is valid 
				// for this application (Basic user input errors are GUI issues, not analysis issues.)
				if (fileContentsAreValid()) {
					lbl_FileFound.setText("File found and the contents are valid!");
					lbl_ErrorDetails.setText("");
					lbl_FileNotFound.setText("");
					btn_Dictionary_Load.setDisable(false);	// Enable the Load button
				}
				
				// If the methods returns false, it means there is a problem with input file
				else {	// and the method has set up a String to explain what the issue is
					lbl_FileFound.setText("");
					lbl_FileNotFound.setText("File found, but the contents are not valid!");
					lbl_ErrorDetails.setText(str_FileContentsError);
					btn_Dictionary_Load.setDisable(true);	// Disable the buttons
				}

			} catch (FileNotFoundException e) {				// If an exception is thrown, 
				lbl_FileFound.setText("");					// set up the messages  and disable 
				lbl_FileNotFound.setText("File not found!");// the buttons.
				lbl_ErrorDetails.setText("");
				scnr_Input = null;								
				btn_Dictionary_Load.setDisable(true);		// Disable the button
			}
	}
	

	/**********
	 * This method reads in the contents of the data file and discards it as quickly as it reads it
	 * in order to verify that the data meets the input data specifications and helps reduce the 
	 * chance that invalid input data can lead to some kind of hacking.
	 * 
	 * @return	true - 	when the input file *is* valid
	 * 					when the input file data is *not* valid - The method also sets a string with
	 * 						details about what is wrong with the input data so the user can fix it
	 */
	private boolean fileContentsAreValid() {
		
		// Declare and initialize data variables used to control the method
		numberOfLinesInTheInputFile = 0;
		String firstLine = "";
		
		// Read in the first line and verify that it has the proper header
		if (scnr_Input.hasNextLine()) {
			firstLine = scnr_Input.nextLine().trim();		// Fetch the first line from the file
			if (firstLine.equalsIgnoreCase("Dictionary"))	// See if it is what is expected
				numberOfLinesInTheInputFile = 1;				// If so, count it as one line
			else {												// If not, issue an error message
				System.out.println("\n***Error*** The first line does not consist of the word \"Dictionary\"" +
						" as required by the specification.");
				return false;								// and return false
			}
		} else {
		// If the execution comes here, there was no first line in the file
			System.out.println("\n***Error*** The file appears to be empty.");
			return false;
		}
		
		// Process each and every subsequent line in the input to make sure that none are too long
		while (scnr_Input.hasNextLine()) {
			numberOfLinesInTheInputFile++;					// Count the number of input lines
			
			// Read in the line 
			String inputLine = scnr_Input.nextLine();
			
			// Verify that the input line is not larger than 250 characters...
			if (inputLine.length() > 250) {
				// If it is larger than 250 characters, display an error message on the console
				System.out.println("\n***Error*** Line " + numberOfLinesInTheInputFile + " contains " + 
						inputLine.length() + " characters, which is greater than the limit of 250.");
				
				// Stop reading the input and tell the user this data file has a problem
				return false;
			}
		}
		
		// Should the execution reach here, the input file appears to be valid
		str_FileContentsError = "";							// Clear any messages
		return true;										// End of file - data is valid
	}

	

	/**********
	 * This private method is called when the Load button is pressed. It tries to load the data into
	 * theData data structure for future analysis, if the user wishes to do that.  The method also
	 * manages the change of state of the various buttons associated with the user interface during
	 * the process.
	 * 
	 * To properly enable the concurrent activities with the user interface, this method uses a
	 * different thread to actually read in the data, leaving this thread available to deal with
	 * any user commands and to update the user interface as the reading takes place (e.g. this
	 * allows the progress bar to be updated *while* the reading is taking place.)
	 */
	private void loadTheData() {
		// Set up the user interface buttons give the user has pressed the Load button
		btn_Dictionary_Load.setDisable(true);			// Disable the Load button, since it was pushed

		try {
			final Scanner dataReader = new Scanner(new File(str_DictionaryFileName));	// Set up scanner
			new Thread(() -> {readTheData(dataReader);}).start();	// Use it on another
																	// thread, running concurrently
		}
		catch (FileNotFoundException e)  {
			// Since we have already done this check, this exception should never happen
			System.out.println("***Error*** A truly unexpected error oNewTextField3ured.");
		}
	};
	
	
	/**********
	 * This private method reads the data from the data file and places it into a data structure
	 * for later processing, should the user decide to do that.  (Recall that the input has already
	 * been scanned by the function fileContentsAreValid(), so redundant checks are not needed.)
	 * 
	 * @param in	The parameter is a Scanner object that is set up to read the input file
	 */
	private void readTheData(Scanner in) {
		// Establish the dictionary
		theDictionary = new Dictionary();
				
		// Read in the dictionary and store what is read in the Dictionary object
		theDictionary.defineDictionary(in);
		
		Platform.runLater(() -> {
			dictionaryFileReadControls.setVisible(false);
			dictionarySetUpFindControls();
		});

	}

	/**********
	 * Display the Dictionary Find controls
	 */
	private void dictionarySetUpFindControls() {
		// Label the text field that specifies the number definitions that have been read in.
		setupLabelUI(lbl_NumberOfDefinitions, "Arial", 14, WINDOW_WIDTH-20, Pos.BASELINE_LEFT, 
				MARGIN_WIDTH, CONTROL_PANEL_HEIGHT);
		lbl_NumberOfDefinitions.setText("The number of definitions: " + theDictionary.getNumEntries());

		// Label the text field that is to receive the search text.
		setupLabelUI(lbl_EnterSearchText, "Arial", 14, WINDOW_WIDTH-20, Pos.BASELINE_LEFT, 
				MARGIN_WIDTH, CONTROL_PANEL_HEIGHT + 25);

		// Establish the text input widget so the user can enter in the name of the file that holds
		// the data about which cells are alive at the start of the simulation
		setupTextUI(fld_SearchText, "Arial", 14, WINDOW_WIDTH / 2, Pos.BASELINE_LEFT, 
				MARGIN_WIDTH, CONTROL_PANEL_HEIGHT + 45, true);
		// Establish the link between the text input widget and a routine that checks to see if
		// if a file of that name exists and if so, whether or not the data is valid
		fld_SearchText.textProperty().addListener((observable, oldValue, newValue) -> {checkSearchText(); });
		
	    Platform.runLater(new Runnable() {public void run() {fld_SearchText.requestFocus();} });

		
		// Establish a GUI button the user presses when the file name have been entered and the
		// code has verified that the data in the file is valid (e.g. it conforms to the requirements)
		setupButtonUI(btn_Search, "Arial", 14, 100, Pos.BASELINE_LEFT, WINDOW_WIDTH - 275,  
				CONTROL_PANEL_HEIGHT + 45);
		
		// Establish the link between the button widget and a routine that loads the data into theData
		// data structure
		btn_Search.setOnAction((event) -> { searchDictionary(); });

		if(fld_SearchText.getText().length() <= 0 )
			btn_Search.setDisable(true);
		else 
			btn_Search.setDisable(false);
		
		dictionaryFindControlsAreSetUp = true;

		dictionaryFindControls.getChildren().addAll(lbl_NumberOfDefinitions, lbl_EnterSearchText, 
				fld_SearchText, btn_Search, lbl_NumberOfSearchItemsFound);

		dictionaryControls.getChildren().add(dictionaryFindControls);
	}
	
	/**********
	 * This method is used to search the dictionary when the search button is pressed
	 */
	private void searchDictionary() {
		// Tell the dictionary what to search for and set the results into the tab's text area
		TextArea newContent = new TextArea(theDictionary.findAll(fld_SearchText.getText()));
		dictionaryTab.setContent(newContent);
		newContent.setEditable(false);
		
		// Get the number of items that were found and display it to the user
		numberOfSearchItemsFound = theDictionary.getNumberSearchItemsFound();
		setupLabelUI(lbl_NumberOfSearchItemsFound, "Arial", 14, WINDOW_WIDTH-20, Pos.BASELINE_LEFT, 
				MARGIN_WIDTH, CONTROL_PANEL_HEIGHT + 75);
		
		lbl_NumberOfSearchItemsFound.setText("The number of search items found: " + numberOfSearchItemsFound);
		
		// Disable the search button (until something changes)
		btn_Search.setDisable(true);
		
		if (!editDeletePopupDisplayed) {
		setupButtonUI(btn_EditPopup, "Arial", 12, 50, Pos.BASELINE_CENTER, WINDOW_WIDTH - 200,  
				CONTROL_PANEL_HEIGHT);
		setupButtonUI(btn_DeletePopup, "Arial", 12, 50, Pos.BASELINE_CENTER, WINDOW_WIDTH - 130,  
				CONTROL_PANEL_HEIGHT);
		dictionaryControls.getChildren().add(btn_EditPopup);
		dictionaryControls.getChildren().add(btn_DeletePopup);
		
		btn_EditPopup.setOnAction((event) -> { setupDictionaryEditPopup(); });
		
		editDeletePopupDisplayed = true;
		}

		
		if (numberOfSearchItemsFound > 0) {
			// Enable the Delete and Edit buttons in order to allow a pop-up to be used to be used
			// be used to edit, or delete a dictionary entry
			btn_EditPopup.setDisable(false);
			btn_DeletePopup.setDisable(false);
		}
		else {
			// No dictionary items found so it is not possible to edit or delete and entry
			btn_EditPopup.setDisable(true);
			btn_DeletePopup.setDisable(true);
		
		}

	}
	
	
	private void setupDictionaryEditPopup() {
	
			// Set up the pop-up modal dialogue window
            editDialog.setTitle("1. Select a definition, 2. Edit it, and then 3. saveNotes it!");
            Group dictionaryEditControls = new Group();
                        
            // Fetch the search string that user had specified.  We know that since the number of
            // search items must be greater than zero for the code to call this method, so there 
            // had to be a search string, it had to be greater than zero characters, and at least 
            // one dictionary item matched it.
            theDictionary.setSearchString(fld_SearchText.getText());
            
            // Reset the comboBox list and the list of definitions back to empty
            editComboBox.getItems().clear();
        	editDefinitionList.clear();

            // Fetch the matching items and place them into a list
            for (int ndx = 0; ndx < numberOfSearchItemsFound; ndx++) {
            	DictEntry d = theDictionary.findNextEntry();
            	editComboBox.getItems().add(d.getWord());
            	editDefinitionList.add(d);
            }
            
            // Set up the pop-up window
            Scene dialogScene = new Scene(dictionaryEditControls, 500, 400);
            
            // Set up the fields for the edit pop-up window
            setupLabelUI(lbl_1SelectDefinition, "Arial", 14, 100, Pos.BASELINE_LEFT, 10, 10);
            setupLabelUI(lbl_2EditDefinition, "Arial", 14, 100, Pos.BASELINE_LEFT, 10, 75);
            setupLabelUI(lbl_2aWord, "Arial", 12, 100, Pos.BASELINE_LEFT, 20, 100);
    		setupTextUI(fld_2aWord, "Arial", 14, 450, Pos.BASELINE_LEFT, 30, 120, true);
            setupLabelUI(lbl_2bDefinition, "Arial", 12, 100, Pos.BASELINE_LEFT, 20, 155);
            setupTextAreaUI(txt_2bDefinition, "Arial", 14, 450, 140, 30, 180, true);
            setupLabelUI(lbl_3saveNotesDefinition, "Arial", 14, 100, Pos.BASELINE_LEFT, 10, 335);
            
            // Set up the comboBox to select one of the dictionary items that matched
            editComboBox.setLayoutX(25);
            editComboBox.setLayoutY(35);
            editComboBox.getSelectionModel().selectFirst();
            editComboBox.setOnAction((event) -> { loadTheEditDefinitionData(); });
            
          
            // Set the screen so we can see it
            editDialog.setScene(dialogScene);
            
            // Load in the current word and definition data into the edit fields
            loadTheEditDefinitionData ();
            
            setupButtonUI(btn_saveNotesEditChanges, "Arial", 12, 50, Pos.BASELINE_LEFT, 30, 360);
            btn_saveNotesEditChanges.setOnAction((event) -> { try {
				saveNotesTheData();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} });
            
            // Populate the pop-up window with the GUI elements
            dictionaryEditControls.getChildren().addAll(editComboBox, lbl_1SelectDefinition, 
            		lbl_2EditDefinition, lbl_2aWord, fld_2aWord, lbl_2bDefinition, 
            		txt_2bDefinition, lbl_3saveNotesDefinition, btn_saveNotesEditChanges);

            // Show the pop-up window
            editDialog.show();
        };

        /**********
         * This method populates the word/phrase to be defined and the definition fields to be
         * edited based on the comboBox selection the user has performed
         */
        private void loadTheEditDefinitionData () {
        	// Fetch the index of the selected item
        	ndxsaveNotesEdit = editComboBox.getSelectionModel().getSelectedIndex();
        	
        	// If the index is < 0, this implies that the default item has been selected... it is
        	// index location zero.
        	if (ndxsaveNotesEdit < 0) ndxsaveNotesEdit = 0;
        	
        	// Fetch the selected items
        	DictEntry d = editDefinitionList.get(ndxsaveNotesEdit);
        	
        	// Extract the word or phrase being defined from the item
        	fld_2aWord.setText(d.getWord());
        	
        	// Extract the definition from the item
        	Scanner definitionScanner = new Scanner(d.getDefinition().substring(1));
        	String theDefinition = "";
        	
        	// Remove the lab from the beginning of line of the definition
        	while (definitionScanner.hasNextLine()) {
        		String line = definitionScanner.nextLine();
        		if (line.length() > 0 && line.charAt(0) == '\t')
        			theDefinition += line.substring(1);
        		theDefinition += '\n';
        	}
        	
        	// saveNotes the definition
        	txt_2bDefinition.setText(theDefinition);
        	
        	// Close the Scanner object
        	definitionScanner.close();
       }

        /**********
         * This method populates the word/phrase to be defined and the definition fields to be
         * edited based on the comboBox selection the user has performed
         */
     //   private void saveNotesTheEditDefinitionData () {
        	// This is a stub to show that the saveNotes operation will indeed saveNotes the altered text,
        	// but it is a stub... it does not actually change the dictionary.  This method must
        	// be altered to actually saveNotes the changes and re-sort the dictionary.
      //  	String saveNotesThisWord = fld_2aWord.getText();
      //  	String saveNotesThisDefinition = txt_2bDefinition.getText();
      //  	System.out.println("\nIndex for the saveNotes: " + ndxsaveNotesEdit);
      //  	System.out.println("\nThe word of phrase for the saveNotes:\n" + saveNotesThisWord);
      //  	System.out.println("\nThe definition for the word or phrase for the saveNotes:\n" + saveNotesThisDefinition);

            // Hide and close the pop-up window
       // 	editDialog.hide();
       //     editDialog.close();

    //  }
	
	/**********
	 * When changes are made to the search text field, we only show the Search button when there is
	 * at least one character in the text field and something has changed since the last time the 
	 * search button has been pressed.
	 */
	private void checkSearchText() {
		// Any change to the search text field means we do not show the number of items found
		// You can call this remove even if the item is not in the list.
		lbl_NumberOfSearchItemsFound.setText("");

		numberOfSearchItemsFound = -1;

		// After the change to the text field, we enable the button if there is at least one
		// character there
		if(fld_SearchText.getText().length() <= 0 )
			btn_Search.setDisable(true);
		else 
			btn_Search.setDisable(false);
		
		// We only enable the edit and the delete buttons when a search has been performed
		if (editDeletePopupDisplayed) {
			editDeletePopupDisplayed = false;
			dictionaryControls.getChildren().remove(btn_EditPopup);
			dictionaryControls.getChildren().remove(btn_DeletePopup);
		}

	}
	
	private void saveNotesTheNotes() throws FileNotFoundException  {
		String Notes = NotesContent.getText();
		
			PrintWriter out = new PrintWriter(new FileOutputStream("Notes.txt"));
			out.write("Notes\n");
			out.write(Notes);
			out.close();
	
	}
	
	private void saveNotesTheList() throws FileNotFoundException  {
		String List = ToDoContent.getText();
			PrintWriter out = new PrintWriter(new FileOutputStream("ToDoList.txt"));
			out.write(List + "\n");
			out.write(ToDoContent.getText()+"\n"+ Spare.getText());
			out.close();
	
	}
	
	private void saveNotesTheData() throws FileNotFoundException  {
		String w = fld_2aWord.getText();
		String d = "\n"+" " +txt_2bDefinition.getText()+"\n";
		
    	theDictionary.addEntry(w, d);
 
    	int numEntriesWritten = 0;
	
			PrintWriter out = new PrintWriter(new FileOutputStream("First20k.txt"));
			out.write("Dictionary\n");
			for (int i=0; i < theDictionary.getNumEntries(); i++) {
				out.println(theDictionary.getDictEntry(i));
				numEntriesWritten++;
			}
			out.close();
		
		System.out.println("The system wrote out " + numEntriesWritten + " entries.");
		
//    	
    	
        // Hide and close the pop-up window
    	editDialog.hide();
        editDialog.close();
	}

	/**********
	 * This method is called when entering or leaving the Spare tab
	 */
	private void spareChanged() {
		if (!spareTab.isSelected()) {
			spare.setVisible(false);
			// When the execution gets here, the user is leaving the tab
			return;}
			spare.setVisible(true);
	}


	public TextArea getContactsContent() {
		return contactsContent;
	}


	public void setContactsContent(TextArea contactsContent) {
		this.contactsContent = contactsContent;
	}
}